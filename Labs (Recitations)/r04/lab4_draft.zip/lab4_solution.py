'''
Lab 4: Sudoku
Rename this file as lab4_solution.py

Introduction:
We have studied depth first search and recursive backtracking.
In this lab, we implement these ideas for sudoku.
We will implement the brute force solution, 
                a recursive backtracking solution 
            and a Python generator solution.
Goals:
    Theoretical Goals
        -To understand backtracking algorithms
        -To understand the connection between depth first search and backtracking
        -To see examples where a brute force algorithm fails.
    Python Goals
        -To understand iterators and generators
        -To practice manipulating lists and indexing in Python.
Gotchas:
    -Remember that lists are mutable. The MySudoku class maintains a single board that is modified repeatedly.
    -You may need to call MySudoku.reset() to clear all the cells that were not given.
    -self.blank_cells refers to the cells that are initially blank (0). They may not be blank during the course of the algorithm.
    -The solving algorithms return a doubly nested list of integers, not a MySudoku object.
    '''

import itertools
from examples import *
import copy
import profile
class MySudoku(object):
    def __init__(self: "MySudoku", board: list[list[int]]) -> None:
        '''
        Input: A board. This is a doubly nested list of digits 0-9. The digit 0 means that the square is blank.
        Output: None
        Side Effects: creates a sudoku board. It stores the indicies of the non-zero digits as a list of pairs called clues.
        '''
        self.board = board
        self.clues = [(i,j) for i in range(9) for j in range(9) if self.board[i][j]>0]
        self.blank_cells = [(i, j) for i in range(9) for j in range(9) if (i,j) not in self.clues]

    def __repr__(self) -> str:
        return "\n".join(["".join([str(r) for r in row]) for row in self.board]) + "\nclue positions: " + str(self.clues)
    
    def check_cell(self, r:int, c:int) -> bool:
        '''
        Input: r and c are indices of a cell.
        Output: True/False, depending on whether this cell violates any Sudoku rule.
        '''
        val = self.board[r][c]
        if val == 0:
            return True

        # row
        for j in range(9):
            if j != c and self.board[r][j] == val:
                return False

        # column
        for i in range(9):
            if i != r and self.board[i][c] == val:
                return False

        # 3x3 box
        br = (r // 3) * 3
        bc = (c // 3) * 3
        for i in range(br, br + 3):
            for j in range(bc, bc + 3):
                if (i != r or j != c) and self.board[i][j] == val:
                    return False

        return True


    def verify(self, full = False) -> bool:
        '''
        Input: full is a Boolean. If True, then each cell must be filled (nonzero).
        Applies self.check_cell to each cell. 
        Returns True if the cell satisfies the sudoku rules.
        '''
        if full:
            if len([entry for row in self.board for entry in row  if entry ==0 ])!=0:
                return False
        for r in range(9):
            for c in range(9):
                if not self.check_cell(r, c):
                    return False
        return True

    def reset(self) -> None:
        '''
        Input: None
        Side-Effects: Sets any non-clues to 0.
        Output: None
        '''
        for i in range(9):
            for j in range(9):
                if (i,j) not in self.clues:
                    self.board[i][j] = 0

    def embed_guess(self, assignment:list[int]) -> None:
        '''
        Input: assignment is a list of integers. They are the numbers that the solver has filled in.
        Output: None
        Side-Effects: Modifies self.boards so that the entries that the solver fills in are modified to fit assignment.
        '''
        assert len(self.blank_cells)==len(assignment)
        for (i, j), val in zip(self.blank_cells, assignment):
                self.board[i][j] = val
    
    def solve_brute_force(self) -> list[list[list[int]]]:
        '''
        Returns the list of solutions.
        Temporarily modifies the board.
        '''
        solutions = []
        for blank_cell_assignment in itertools.product(range(1,10), repeat = 81- len(set(self.clues))):
            self.embed_guess(blank_cell_assignment)

            if self.verify():
                solutions.append(copy.deepcopy(self.board))
        self.reset()
        return solutions

    def solve_backtracking(self) -> list[list[list[int]]]:
        """
        Solve the Sudoku using recursive backtracking.
        Returns True if solved, False otherwise.
        Temporarily modifies the board, then resets it.
        """
        solutions = []
        def backtrack(idx=0):
            #idx is the number of the blank cell.
            nonlocal solutions
            if idx == len(self.blank_cells):
                # All blanks filled, solution found
                solutions.append(copy.deepcopy(self.board))
                return

            r, c = self.blank_cells[idx]
            for val in range(1, 10):
                self.board[r][c] = val
                if self.check_cell(r, c):
                    backtrack(idx + 1)
                self.board[r][c] = 0  # undo for next attempt
            return solutions
        backtrack()
        self.reset()
        return solutions

    def __iter__(self): #This dunder method allows looping through MySudoku objects.
        yield from copy.deepcopy(self).solve(0)

    def solve(self, i):
        if i == len(self.blank_cells):
            yield self
            return
        r,c = self.blank_cells[i]
        for v in range(1,10):
            self.board[r][c] = v
            if self.check_cell(r,c):
                yield from self.solve(i+1)
        self.board[r][c] = 0
    
    def lazy_iterative_search(self):
        '''
        Input: None
        Output: A generator for the solutions to the sudoku puzzle.
        Side-Effects: None
        '''
        return (copy.deepcopy(s.board) for s in self)
#---#
if __name__=="__main__":
    S=MySudoku(medium_puzzle)
    sol = S.solve_brute_force()
    assert len(sol)==1
    assert MySudoku(sol[0]).verify()
# S = MySudoku(hard_puzzle)
# S.reset()
# profile.run(
# '''for s in S.lazy_iterative_search():
#     print(s)''')
# S.reset()
# profile.run("S.solve_backtracking()")
