'''This file should contain all of the tools that you use to solve the cube.
Be sure that there is a solve method implemented here.'''
from pocket_cube import *
from functools import lru_cache #used for caching
from heapq import heappush, heappop 
from collections import deque

def BFS(source,                                                  #source is the node where the search starts.
        condition = lambda cube: cube.is_solved(),  #condition is a function that expects a node and returns a bool that is True if we've found what we're looking for.
        get_neighbors=lambda cube: cube.get_neighbors(),         #get_neighbors is a function that expects a node and returns the neigbors of that node.
        continue_condition=lambda visited: True):                #continue_condition is a function that expects a the dictionary, visited. If function returns False, the search terminates.
    """
    Performs a breadth first search from a source node.

    Args:
        source: The starting node of the search. Could be any hashable type (no lists or sets). 
        condition (callable, optional): Function that takes a node and returns True 
            if the goal is reached. Defaults to a function that checks if 
            cube.state equals the solved state.
        get_neighbors (callable, optional): Function that takes a node and returns 
            its neighbors. Defaults to cube.get_neighbors().
        continue_condition (callable, optional): Function that takes the visited 
            dictionary and returns True if the search should continue. Defaults to always True.

    Returns:
        tuple: (last_node, visited)
            - last_node: The node found by the search  or None, if the search is discontinued.
            - visited (dict): Keys are nodes that have been visited, values are the last move (str) to reach that node 
              in the shortest path from the source.
    
    returns the last node found and a dictionary: 
    The keys are the nodes found in the search. 
    The value is the last move in the shortest paths to get to the key node.
    """
    frontier = deque() #dequeue is a doubly ended queue. You may need .append() .extend() and .popleft() methods.
    frontier.append((source,"_"))
    visited = {}
    while len(frontier)>0 and continue_condition(visited):
        current,move = frontier.popleft()
        if current in visited:
            continue
        else:
            visited[current]=move
        if not condition(current):
            neighbors = {(neighbor,move) for neighbor, move in get_neighbors(current) if neighbor not in visited}
            frontier.extend(neighbors)
        else:
            return current, visited
    return None, visited
def dijkstra(
    source, 
    condition=lambda cube: cube.is_solved(),
    get_neighbors=lambda cube: cube.get_neighbors(),
    continue_condition=lambda visited: True
):
    """
    Performs Dijkstra's search from a source node.

    Args:
        source: The starting node of the search. Could be any hashable type (no lists or sets). 
        condition (callable, optional): Function that takes a node and returns True 
            if the goal is reached. Defaults to a function that checks if 
            cube.state equals the solved state.
        get_neighbors (callable, optional): Function that takes a node and returns 
            its neighbors. Defaults to cube.get_neighbors().
        continue_condition (callable, optional): Function that takes the visited 
            dictionary and returns True if the search should continue. Defaults to always True.

    Returns:
        tuple: (last_node, visited)
            - last_node: The last node found by the search (may be the goal or the last expanded node), or None, if the search space is exhausted.
            - visited (dict): Keys are nodes that have been visited, values are the last move (str) to reach that node 
              in the shortest path from the source.
    """
    frontier = []
    heappush(frontier, (0, source, "_"))
    visited = {}  # store the final shortest paths for each node.

    while len(frontier)>0 and continue_condition(visited):
        distance, node, move = heappop(frontier)
        if node not in visited:
            visited[node] = move
            if condition(node):
                return node, visited
            for neighbor, move in get_neighbors(node):
                heappush(frontier, (distance 
                        + PocketCube.move_cost_dict[move], neighbor, move))
    return None, visited

def solve_small_scramble(cube:"PocketCube", method = "BFS") -> list[str]:
    '''
    Args:
        cube is a PocketCube to slove. 
        method is a string that allows you to choose between different functions (not necessary to implement)
    Returns:
        A list of moves that return the cube to its original state.
    Side Effects:
        None. Does not modify cube.
    '''
    if method == "BFS":
        _, visited = BFS(cube,condition=lambda cube: cube.is_solved())
    elif method == "dijkstra":
        _, visited = dijkstra(cube, condition=lambda cube: cube.is_solved())
    solve_seq = get_path_from_search(cube,PocketCube(),visited)
    return solve_seq
def get_path_from_search(source, target, visited):
    """
    Reconstructs the path from a source vertex to a target vertex using a visited dictionary.

    Args:
        source: The starting vertex (of type Pocket Cube). Typically, this is the scrambled cube.
        target: The destination vertex (of type Pocket Cube). Typically, this is the source cube.
        visited (dict): A dictionary where keys are vertices and values are 
            the move that leads to that vertex from its predecessor.

    Returns:
        list: A sequence of moves that takes you from the source to the target.

    Notes:
        - If you encounter a KeyError (e.g., "key error '_p'"), it may be because 
          the source and target are reversed. Try switching them.
    """
    move_sequence = []
    current = PocketCube(state = target.state)
    while current != source:
        mv = visited[current]
        if isinstance(mv, tuple):
            mv = list(mv)
        else: #in this case, mv is just a string.
            mv = [mv]
        mv = PocketCube.invert_move_sequence(mv)
        move_sequence.extend(mv)
        current.perform_move_sequence(mv)
    return PocketCube.invert_move_sequence(move_sequence)
def solve_cube_method1(cube):
    '''
    Returns: 
        the sequence (list) of moves that transforms cube into the solved cube.
    The solution is to perform BFS until you find a better configuration, meaning more cubies are correctly placed and oriented.
    Once one cubie is correctly placed and oriented, only consider moves that fix that cubie.
    Once two adjacent cubies are correctly placed and oriented, only consider moves that fix those two cubies. 
       This sometimes exhausts the search space and doesn't find a solution.
       If you exhaust the search space, fall back and no longer require that the second cubie be fixed.
    This seems to work, but there's no proof, and it's concieveable it enters an infinite loop for some input.
    '''
    current_cube = PocketCube(state = cube.state)
    total_move_sequence = []
    correctly_placed_cubie1=None
    correctly_placed_cubie2=None
    while current_cube.state != list(range(24)):
        if current_cube.num_nonfixed()[0]==0:
            if correctly_placed_cubie2 is None:
                correct_pair = current_cube.get_adjacent_pair_of_correctly_placed_and_oriented_cubies()
                if not correct_pair is None:
                    correctly_placed_cubie1, correctly_placed_cubie2=correct_pair
            if correctly_placed_cubie1 is None:
                correctly_placed_and_oriented_cubies = current_cube.correctly_placed_cubies(orientation=True)
                if len(correctly_placed_and_oriented_cubies)>0:
                    correctly_placed_cubie1=correctly_placed_and_oriented_cubies[0]
            if not correctly_placed_cubie1 is None and correctly_placed_cubie2 is None:
                print("correctly_placed",correctly_placed_cubie1,current_cube)
                #next_cube, visited = dijkstra(current_cube,None, condition = lambda cube: cube.almost_solved())
                next_cube, visited = BFS(current_cube, condition= lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed(), get_neighbors=lambda cube: cube.get_neighbors_avoiding(correctly_placed_cubie1))
            elif not correctly_placed_cubie1 is None and not correctly_placed_cubie2 is None:
                print("correct pair", correctly_placed_cubie1,correctly_placed_cubie2,current_cube)
                next_cube, visited = BFS(current_cube, condition= lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed(), get_neighbors=lambda cube: cube.get_neighbors_avoiding(correctly_placed_cubie1) & cube.get_neighbors_avoiding(correctly_placed_cubie2))
                if next_cube is None: #occurs if the search space is exhausted.
                    print("falling back")
                    correctly_placed_cubie2=None
                    next_cube, visited = BFS(current_cube, condition= lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed(), get_neighbors=lambda cube: cube.get_neighbors_avoiding(correctly_placed_cubie1))

            else:
                next_cube, visited = BFS(current_cube, condition = lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed())
        else:
            #print("should only happen once")
            #next_cube, visited = dijkstra(current_cube,None, condition = lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed())
            next_cube, visited = BFS(current_cube, condition = lambda cube: cube.num_nonfixed()<current_cube.num_nonfixed())

        #move_sequence = find_optimal_sequence(current_cube,next_cube,visited)
        move_sequence = get_path_from_search(current_cube, next_cube, visited)
        total_move_sequence.extend(move_sequence)
        current_cube = next_cube
        print(current_cube)
        print(current_cube.num_nonfixed())
        print(total_move_sequence)
        print(len(total_move_sequence))
        print(PocketCube.invert_move_sequence(total_move_sequence))
    return total_move_sequence
def solve_cube_method2(cube):
    '''Another method to solve the cube.
        Returns:
            a list of moves to perform
        Notes:
            The method works by:
                1.) Search near the solved cube and store the resulting dictionary.
                2.) Search from the input cube for a cube that has two adjacent cubes with the same placement and orientation as a cube near the solved cube.
                3.) Search for a solution that goes between the two cubes identified in step 2. If not, continue in step 2.
    '''
    def similar_to_cube_in_solved_neighborhood(cube,solved_neighborhood):
        for nearly_solved_cube in solved_neighborhood:
            cubies = cube.get_adjacent_pair_of_correctly_placed_and_oriented_cubies(nearly_solved_cube)
            if cubies is None:
                continue
            else:
                cubie1, cubie2 = cubies
                nearby_solved, intermediate_neighborhood = dijkstra(cube,
                                                                    condition= lambda cube: cube==nearly_solved_cube, 
                                                                    get_neighbors=lambda cube: cube.get_neighbors_avoiding(cubie1) & cube.get_neighbors_avoiding(cubie2))
                if nearby_solved is None:
                    continue
                else: 
                    return nearby_solved, intermediate_neighborhood
        return False
    #Step 1:
    #print("step 1")
    solved_cube = PocketCube()
    _, solved_neighborhood = dijkstra(solved_cube, condition= lambda cube: False, continue_condition=lambda visited: len(visited)<=3*18**3)
    
    #Step 2:
    #print("step 2")
    nearby_scrambled, scrambled_neighborhood = dijkstra(cube, 
                                                        condition = lambda cube: similar_to_cube_in_solved_neighborhood(cube,solved_neighborhood))

    #(cubie1,cubie2),nearby_solved = [(nearby_scrambled.get_adjacent_pair_of_correctly_placed_and_oriented_cubies(nearly_solved) ,nearly_solved) for nearly_solved in solved_neighborhood if not nearby_scrambled.get_adjacent_pair_of_correctly_placed_and_oriented_cubies(nearly_solved) is None][0]
    nearby_solved, intermediate_neighborhood = similar_to_cube_in_solved_neighborhood(nearby_scrambled,solved_neighborhood)
    #Step 3
    #print("step 3")
    #_, intermediate_neighborhood = dijkstra(nearby_scrambled,condition= lambda cube: cube==nearby_solved, get_neighbors=lambda cube: cube.get_neighbors_avoiding(cubie1) & cube.get_neighbors_avoiding(cubie2))
    
    move_seq1 = get_path_from_search(cube,nearby_scrambled,scrambled_neighborhood)
    move_seq2 = get_path_from_search(nearby_scrambled,nearby_solved,intermediate_neighborhood)
    move_seq3 = get_path_from_search(solved_cube,nearby_solved, solved_neighborhood)
    move_seq3 = PocketCube.invert_move_sequence(move_seq3)
    return move_seq1+move_seq2+move_seq3
def improve_move_sequence(move_seq):
    #assumes move_seq is a sequence of moves that solves the cube.
    reverse_seq = PocketCube.invert_move_sequence(move_seq)
    P= PocketCube()
    checkpoints=[]
    cost = 0
    move_seq = []
    for index, mv in enumerate(reverse_seq):
        if index %5==0:
            checkpoints.append(PocketCube(state=P.state))
        P.perform_move(mv,mutate=True)
        cost=cost+PocketCube.move_cost_dict[mv]
    if P not in checkpoints:
        checkpoints.append(P)
    cube = PocketCube()
    while cube !=P:
        index = checkpoints.index(cube)
        next_cube, visited = dijkstra(cube, condition = lambda cube: cube in checkpoints[index+1:])
        move_seq.extend(get_path_from_search(cube,next_cube,visited))
        #print(move_seq)
        cube=next_cube
    #print(move_seq)
    #print("new cost",PocketCube.move_sequence_cost(move_seq))
    return PocketCube.invert_move_sequence(move_seq)
def repeatedly_improve_move_seq(move_seq):
    cost = PocketCube.move_sequence_cost(move_seq)
    improved_sequence = improve_move_sequence(move_seq)
    while PocketCube.move_sequence_cost(improved_sequence) < cost:
        cost = PocketCube.move_sequence_cost(improved_sequence)
        improved_sequence = improve_move_sequence(improved_sequence)
        print("cost is now", cost)
    return improved_sequence

#This method is the preprocessing step for the A* algorithm.
@lru_cache(maxsize=None) #This decorator ensures that this function will only compute once. After that
def create_pruning_table():
    '''
    Args:
        None
    Returns:
        A pair of dictionaries: a cubie_table and a twist_table
        The keys are (respectively) twists of the cubies, and permutations of the cubies. They are the output of PocketCube.get_permutation_twist_rep()
        The values are the lengths of the shortest paths to an untwisted cube, and a cube where the cubies are in the correct locations, respectively.
    Notes:
        If the cost metric is fixed, the outputs of this function could be hardcoded. 
        This function takes about a minute to run on my machine.
    '''

    def get_twist_neighbors(twist_list):
        '''
        Args:
            twist_list is a tuple of -1, 0, 1 of length 8.
        Returns:
            A list of tuples (tl, mv), 
            where tl is the neighboring twist_list 
            that is the result of applying the move mv to twist_list.
        '''
        facelist = PocketCube.get_facelist_from_permutation_twists(list(range(8)),twist_list)
        return [(tuple(N[0].get_permutation_twist_rep()[1]), N[1] ) for N in PocketCube(facelist).get_neighbors()]

    def get_permutation_neighbors(permutation):
        '''
        Args
            permutation is a tuple of numbers 0-7 that represents a permutation of the cubies.
        Returns:
            A list of tuples (p, mv), 
            where p is the neighboring permutation of the cubies
            that is the result of applying the move mv to permutation.
        '''
        facelist = PocketCube.get_facelist_from_permutation_twists(list(permutation),[0] * 8)
        return [(tuple(N[0].get_permutation_twist_rep()[0]), N[1] ) for N in PocketCube(facelist).get_neighbors()]

    cubie_table = dijkstra(tuple(range(8)), condition = lambda x: False,
                           get_neighbors=get_permutation_neighbors,
                            continue_condition= lambda visited: len(visited)<=40320)[1] # len(visited) == 8!

    twist_table = dijkstra(tuple([0]*8), condition=lambda x: False, 
                                get_neighbors=get_twist_neighbors,
                                continue_condition=lambda visited: len(visited)<=3**7)[1]
    #convert the values in the cubie_table dictionary from best, last moves to total costs.
    for permutation in cubie_table: #Since Python 3.7, dictionaries loop in the same order that the keys were added.
        if permutation == tuple(range(8)):
            cubie_table[permutation] = 0
        else:
            P = PocketCube(PocketCube.get_facelist_from_permutation_twists( list(permutation), [0] * 8))
            move = cubie_table[permutation]
            backwards_move = PocketCube.invert_move_sequence([move])[0]
            P.perform_move(backwards_move,mutate=True)
            cubie_table[permutation] = cubie_table[tuple(P.get_permutation_twist_rep()[0])] + PocketCube.move_cost_dict[move]
    for twist in twist_table: #Since Python 3.7, dictionaries loop in the same order that the keys were added.
        if twist == tuple([0] * 8):
            twist_table[twist] = 0
        else:
            P = PocketCube(PocketCube.get_facelist_from_permutation_twists( list(range(8)), list(twist)))
            move = twist_table[twist]
            backwards_move = PocketCube.invert_move_sequence([move])[0]
            P.perform_move(backwards_move,mutate=True)
            twist_table[twist] = twist_table[tuple(P.get_permutation_twist_rep()[1])] + PocketCube.move_cost_dict[move]

    return cubie_table, twist_table
    
def A_star_search(
    source,
    heuristic,
    condition=lambda cube: cube.state == list(range(24)),
    get_neighbors=lambda cube: cube.get_neighbors(),
    continue_condition=lambda visited: True,
):
    """
    Performs the A star search from a source node.

    Args:
        source: The starting node of the search. Could be any hashable type
        heuristic: a function that takes a node and returns a lower bound on the distance to a vertex that we are seeking.
        condition (callable, optional): Function that takes a node and returns True 
            if the goal is reached. Defaults to a function that checks if 
            cube.state equals the solved state.
        get_neighbors (callable, optional): Function that takes a node and returns 
            its neighbors. Defaults to cube.get_neighbors().
        continue_condition (callable, optional): Function that takes the visited 
            dictionary and returns True if the search should continue. Defaults to always True.

    Returns:
        tuple: (last_node, visited)
            - last_node: The last node found by the search (may be the goal or the last expanded node).
            - visited (dict): Keys are nodes visited, values are the last move to reach that node 
              in the shortest path from the source.
    """
    frontier = []
    heappush(frontier, (heuristic(source), source, "_"))
    visited = {}  # store the final shortest paths for each node.

    while len(frontier) > 0 and continue_condition(visited):
        distance_plus_heuristic, node, move = heappop(frontier)
        distance = distance_plus_heuristic - heuristic(node)
        if node not in visited:
            visited[node] = move
            if condition(node):
                return node, visited
            for neighbor, move in get_neighbors(node):
                heappush(frontier, (distance + PocketCube.move_cost_dict[move] 
                                    +heuristic(neighbor), neighbor, move))
    return None, visited

def solve_cube_A_star(P):
    '''
    Uses the A star search method to solve the cube.
    '''
    permutation_table, twist_table = create_pruning_table()
    def heuristic(cube:"PocketCube") -> float:
        permutation, twist = cube.get_permutation_twist_rep()
        return max(permutation_table[tuple(permutation)], twist_table[tuple(twist)])
    visited = A_star_search(P, heuristic)[1]
    return get_path_from_search(P, PocketCube(), visited)

def solve_cube(cube, method="a_star"):
    '''provides a single function that lets you choose the method of solution using the method flag.
    Expects a scrambled cube, cube and a method to solve.
    Returns a move sequence that unscrambles the cube. Does not mutate cube.'''
    if method == "method1":
        return solve_cube_method1(cube)
    elif method == "method2":
        return solve_cube_method2(cube)
    elif method == "BFS":
        return solve_small_scramble(cube, "BFS")
    elif method == "dijkstra":
        return solve_small_scramble(cube, "dijkstra")
    elif method == "a_star":
        return solve_cube_A_star(cube)
    else:
        raise "Invalid method"